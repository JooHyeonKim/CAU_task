package collection;

import java.util.*;

public class Ex02 {

	public static void main(String[] args) {
		
		// String타입의 ArrayList를 생성한 후
		// 연예인 5명 이름을 넣어보자
		// 이름을 향상된 for문과 일반 for문으로 출력하기 
		
		ArrayList<String> list = new ArrayList<>();
		
		list.add("유재석");
		list.add("박명수");
		list.add("정준하");
		list.add("정형돈");
		list.add("하하");
		
		for(String name : list) {
			
			System.out.println(name);
			
		}
		System.out.println();
		
		for(int i = 0; i < list.size(); i++) {
			
			String name = list.get(i);
			System.out.println(i + " : " + name);
			
		}
		
		
	}

}
