package com.jsp.kgmember;

import javax.sql.*;
import java.sql.*;
import javax.naming.*;
import java.util.*;

public class KGMemberDAO {
	
	// DAO : Data Access Object 
	// 데이터베이스에 접근하기 위한 객체 (CRUD를 위한 객체)
	
	// 싱글톤 패턴
	// 싱글톤 : 단 하나의 객체만 생성하는 것
	
	// 싱글톤을 쓰는 이유
	// 고정된 메모리 영역을 얻으면서 한번의 new로 인스턴스를 사용하기 때문에 
	// 메모리 낭비를 방지할 수 있다.
	// 싱글톤으로 만들어진 클래스의 인스턴스는 전역 인스턴스이기 때문에 
	// 다른 클래스의 인스턴스들이 데이터를 공유하기 쉽다.
	// DBCP(DataBase Connection Pool)처럼 공통된 객체를 
	// 여러개 생성해서 사용해야하는 상황에서 많이 사용한다.
	
	private DataSource ds;
	// DataSource 객체는 Connection Pool을 관리하는 객체
	
	private Connection conn;
	private PreparedStatement pstmt;
	// 1. Statement 객체를 상속받은 인터페이스로 Statement의 기능향상
	//    (여러번 수행할때 빠른속도)
	// 2. 코드 안정성과 가독성이 높다.
	private ResultSet rs;
	
	
	private KGMemberDAO() {
		
		try {
			
			Context context = new InitialContext();
			// JNDI 서비스를 제공하는 객체를 생성한다.
			// JNDI : Java Naming & Directory Interface
			//        "이름"을 가지고 데이터베이스의 정보(객체)를 얻을 수 있는 API
			
			ds = (DataSource)context.lookup("java:comp/env/jdbc/oracle");
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		
	}
	
	private static KGMemberDAO instance = new KGMemberDAO();
	
	public static KGMemberDAO getInstance() {
		return instance;
	}
	
	
	// 데이터 넣는 메소드
	public int insertKGMember(KGMemberDTO dto) {
		
		int result = 0;
		
		String query = "insert into KGMember(id, pw, name, age, phone) "
				+ "values(?, ?, ?, ?, ?)";
		
		try {
			
			conn = ds.getConnection();
			pstmt = conn.prepareStatement(query);
			
			pstmt.setString(1, dto.getId());
			pstmt.setString(2, dto.getPw());
			pstmt.setString(3, dto.getName());
			pstmt.setInt(4, dto.getAge());
			pstmt.setString(5, dto.getPhone());
			
			result = pstmt.executeUpdate();
			// 반환값은 레코드의 수
			
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			try {
				if(pstmt != null)pstmt.close();
				if(conn != null)conn.close();
			}catch(Exception e2) {}
		}
		
		return result;
	}
	
	
	
	// 데이터 얻는 메소드
	
	public ArrayList<KGMemberDTO> list(){
		
		ArrayList<KGMemberDTO> list = new ArrayList<KGMemberDTO>();
		
		String query = "select * from KGMember";
		
		try {
			
			conn = ds.getConnection();
			pstmt = conn.prepareStatement(query);
			
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				
				String id = rs.getString("id");
				String pw = rs.getString("pw");
				String name = rs.getString("name");
				int age = rs.getInt("age");
				String phone = rs.getString("phone");
				
				list.add(new KGMemberDTO(id, pw, name, age, phone));
				
			}
			
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			
			try {
				
				if(rs != null)rs.close();
				if(pstmt != null)pstmt.close();
				if(conn != null)conn.close();
				
			}catch(Exception e2) {}
			
		}
		
		
		return list;
	}
	
	
	
	
}






