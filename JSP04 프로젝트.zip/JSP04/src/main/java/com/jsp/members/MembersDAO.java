package com.jsp.members;

import java.util.*;
import java.sql.*;
import javax.sql.*;
import javax.naming.*;

public class MembersDAO {
	
	private DataSource ds;
	
	// 싱글톤 패턴으로 하기 
	// 생성자에서  DataSource 필드 초기화하기
	private MembersDAO() {
		try {
			Context context = new InitialContext();
			
			ds = (DataSource)context.lookup("java:comp/env/jdbc/oracle");
			
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	private static MembersDAO instance = new MembersDAO();
	
	public static MembersDAO getInstance() {
		return instance;
	}
	
	private Connection conn;
	private PreparedStatement pstmt;
	private ResultSet rs;
	
	private void close(Connection conn) {
		try {
			if(conn != null) {
				conn.close();
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	private void close(PreparedStatement pstmt) {
		try {
			if(pstmt != null) {
				pstmt.close();
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	private void close(ResultSet rs) {
		try {
			if(rs != null) {
				rs.close();
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	// 회원가입 후에 회원의 데이터를 DB에 넣는 메소드
	public int insertMember(MembersDTO dto) {
		int result = 0;
		
		String query = "insert into members(id, pw, name, email, address) "
				+ "values(?, ?, ?, ?, ?)";
		
		try {
			
			conn = ds.getConnection();
			pstmt = conn.prepareStatement(query);
			
			pstmt.setString(1, dto.getId());
			pstmt.setString(2, dto.getPw());
			pstmt.setString(3, dto.getName());
			pstmt.setString(4, dto.getEmail());
			pstmt.setString(5, dto.getAddress());
			
			result = pstmt.executeUpdate();
			
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			
			close(pstmt);
			close(conn);
			
		}
		
		return result;
	}
	
	// members 테이블에 같은 아이디가 있는지 확인하는 메소드
	// 멤버가 존재한다면 1, 존재하지 않는다면 0
	public int confirmId(String id) {
		int result = 0;
		
		String query = "select id from members where id = ?";
		
		try {
			
			conn = ds.getConnection();
			pstmt = conn.prepareStatement(query);
			
			pstmt.setString(1, id);
			
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				// 멤버가 존재할때
				result = 1;
			}else {
				// 멤버가 존재하지 않을때
				result = 0;
			}
			
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			
			close(rs);
			close(pstmt);
			close(conn);
			
		}
		
		
		return result;
	}
	
	
	// 로그인 체크해주는 메소드 
	// 아이디와 비밀번호를 매개값으로 받아서 members 테이블에 같은 아이디가 있는지 확인 후
	// 같은 아이디가 있으면 그 아이디에 해당하는 비밀번호가 맞는지 확인하는 메소드
	// 아이디가 존재하지 않는다면 -1, 아이디가 존재하고 비밀번호가 (틀린경우 0, 맞는경우 1)
	public int userCheck(String id, String pw) {
		int result = 0;
		
		String query = "select pw from members where id = ?";
		
		try {
			
			conn = ds.getConnection();
			pstmt = conn.prepareStatement(query);
			
			pstmt.setString(1, id);
			
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				// 아이디가 존재하는 경우
				
				String dbPw = rs.getString("pw");
				
				if(pw.equals(dbPw)) {
					result = 1; // 로그인 OK
				}else {
					result = 0; // 비밀번호가 틀린경우
				}
				
				
			}else {
				// 아이디가 존재하지 않는경우
				result = -1;
			}
			
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			
			close(rs);
			close(pstmt);
			close(conn);
			
		}
		
		return result;
	}
	
	
	// 해당회원의 정보를 얻는 메소드
	public MembersDTO getMember(String id) {
		MembersDTO dto = null;
		
		String query = "select * from members where id = ?";
		
		try {
			
			conn = ds.getConnection();
			pstmt = conn.prepareStatement(query);
			pstmt.setString(1, id);
			
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				
				String dbId = rs.getString("id");
				String pw = rs.getString("pw");
				String name = rs.getString("name");
				String email = rs.getString("email");
				Timestamp regTime = rs.getTimestamp("regDate");
				String address = rs.getString("address");
				
				dto = new MembersDTO(dbId, pw, name, email, regTime, address);
				
			}
			
			
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			
			close(rs);
			close(pstmt);
			close(conn);
			
		}
		
		return dto;
	}
	
	
	// 회원 정보를 수정해주는 메소드
	// (비밀번호 이메일 주소)
	public int updateMember(MembersDTO dto) {
		int result = 0;
		
		String query = "update members set pw=?, email=?, address=? where id=?";
		
		try {
			
			conn = ds.getConnection();
			pstmt = conn.prepareStatement(query);
			
			pstmt.setString(1, dto.getPw());
			pstmt.setString(2, dto.getEmail());
			pstmt.setString(3, dto.getAddress());
			pstmt.setString(4, dto.getId());
			
			result = pstmt.executeUpdate();
			
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			close(pstmt);
			close(conn);
		}
		
		return result;
	}
	
	// 해당 회원을 삭제해주는 메소드
	public int deleteMember(String id) {
		int result = 0;
		
		String query = "delete from members where id = ?";
		
		try {
			
			conn = ds.getConnection();
			pstmt = conn.prepareStatement(query);
			
			pstmt.setString(1, id);
			
			result = pstmt.executeUpdate();
			
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			close(pstmt);
			close(conn);
		}
		
		return result;
	}
	
	
	
}
















